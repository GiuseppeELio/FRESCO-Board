#pragma once

#include "AppleMIDI_Namespace.h"

BEGIN_APPLEMIDI_NAMESPACE

#ifdef WIN32
#pragma pack(pop)
#endif
#undef PACKED

END_APPLEMIDI_NAMESPACE
