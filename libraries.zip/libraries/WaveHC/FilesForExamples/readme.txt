

piwave - File for the PiSpeakHC.pde and some versions of the Adafruit 
         wavehc_play6 example.  Copy these files to the root directory 
         of your SD.

DO_RE_MI - Used by many versions of Adafruit wavehc_play6 example.
           Pick one version of the do-re-mi files and copy them to 
           the root directory of your SD.


You can place the files from piwave and one version of the do-re-mi files
in the root directory of an SD.  This SD can be used with PiSpeakHC and
the versions of wavehc_play6.


DTMF and fill - Files for the openByIndex.pde example. DTMF files are phone 
                'touch tones'. fill contains dummy files to fill the directory.
                See the openByIndex.pde sketch for instructions.
