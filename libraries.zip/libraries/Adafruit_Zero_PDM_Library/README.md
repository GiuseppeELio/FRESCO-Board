# Adafruit Zero PDM Library [![Build Status](https://github.com/adafruit/Adafruit_ZeroPDM/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_ZeroPDM/actions)[![Documentation](https://github.com/adafruit/ci-arduino/blob/master/assets/doxygen_badge.svg)](http://adafruit.github.io/Adafruit_ZeroPDM/html/index.html)

PDM microphone library for the Arduino Zero / Adafruit Feather M0 (SAMD21 processor).
