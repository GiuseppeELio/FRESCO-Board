Arduino-Due-RTC-Library
=======================

RTC Library for the Arduino Due, now outdated use the new https://github.com/MarkusLange/RTCDue keep in mind the first day of the week has changed from Monday to Sunday as usual by other RTC librarys.
