Per maggiori informazioni sull'installazione di librerie guarda http://www.arduino.cc/en/Guide/Libraries
